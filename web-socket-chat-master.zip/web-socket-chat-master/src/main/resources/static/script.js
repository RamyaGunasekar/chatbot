var currentModule = "";
var currentData = [];
var counter = 0;

function connect() {
	/*var socket = new SockJS('/chat-messaging');
	stompClient = Stomp.over(socket);
	stompClient.connect({}, function(frame) {
		console.log("connected: " + frame);
		if($('.messages').html()==="")
		{
		draw("left","Holla, I'm your Toyota Bot. A new way to enhance your domain knowledge. How can I help you ?");
		}
		stompClient.subscribe('/chat/messages', function(response) {
			var output = JSON.parse(response.body);
			var data=output.response;
			counter = 0;
			currentData = data;
			draw("right", $("#message_input_value").val());
			draw("left", data[0]);
			console.log(data);
			console.log(data.length);
			console.log(counter);
			if(data.length > 1 && counter < data.length){
				setTimeout(function(){
					draw("left", '<span>do u want to know more ? </span><button id="yes" onclick="yes(this)">yes</button> <button id="no" onclick="no(this)">No</button>');
				},500);
				
				
			}
			$("#message_input_value").val("");
		});
	});
	*/
	
	 $.ajax({
	        url: '/chat/messages',
	        		type:"POST",
	        		dataType: "json",
	        		contentType: 'application/json',
	        		data: JSON.stringify({'message': $("#message_input_value").val(),'appName':currentModule}),
	        		success: function(response, textStatus, jqXHR) {
	        			var output = response;
	    				var data=output.response;
	    				counter = 0;
	    				currentData = data;
	    				draw("right", $("#message_input_value").val());
	    				draw("left", data[0]);
							voiceout(data[0]);
	    				console.log(data);
	    				console.log(data.length);
	    				console.log(counter);
	    				if(data.length > 1 && counter < data.length){
	    					setTimeout(function(){
	    							draw("left", ' <span style=" font-weight: 550; font-size: 15.5px;">Do you want to know more about this ? </span> <button id="yes" onclick="yes(this)" style=" font-weight: 600; border-radius: 10px; background-color: #05ab05;color: white;">yes</button> <button id="no" onclick="no(this)" style="font-weight: 700; border-radius: 10px;color: white; background-color: rgb(251, 22, 5);border-color: #c58a7c;">No</button>');
				},500);
				var knowMore="Do you want to know more about this ? Click Yes or No";
				voiceout(knowMore);
	    					
	    					
	    				}
	    				$("#message_input_value").val("");
	        		},
	        		error: function (jqXHR, textStatus, errorThrown)
	        	    {
	        	 
	        	    }
	 });
	        	       
}
function voiceout(text) {
	
	var msg = new SpeechSynthesisUtterance(text);
	speechSynthesis.speak(msg);
	}
/*function voiceover() {
	speechSynthesisInstance.cancel();
	}*/


function voiceText() {
	//var SpeechGrammarList =["NAPO","IPLUS","RDR"];
	 var recognition = new webkitSpeechRecognition();
	 console.log(recognition);
	    recognition.onresult = function(event) {
	    	console.log(event);
	      if (event.results.length > 0) {
	    	console.log(event.results[0][0].transcript);
	    	 // $("#message_input_value").val(event.results[0][0].transcript);
	    	  $("#message_input_value").eq(0).val(event.results[0][0].transcript).trigger("keyup");
	    	 
	      }
	    }
	    recognition.maxAlternatives = 1;
	    recognition.lang = 'en-US';
	    recognition.interimResults = false;
	    var grammar = '#JSGF V1.0; grammar projects; public <project> = NAPO | RDR | IPLUS | TMS | TFS ;'
	    	//var recognition = new webkitSpeechRecognition();
	    	var speechRecognitionList = new webkitSpeechGrammarList();
	    	speechRecognitionList.addFromString(grammar, 1);
	    	recognition.grammars = speechRecognitionList;
	    recognition.start();
	    recognition.onstart = function(event) {
	    	$("#message_input_value").eq(0).val("listenting....");
	    }
	    recognition.onnomatch = function(event) {
	    	$("#message_input_value").eq(0).val("no match....");
	    }
	    recognition.onerror = function(event) {
	    	$("#message_input_value").eq(0).val("Mic is not enabled check settings");
	    }
	    recognition.onspeechend = function() {
	    	  recognition.stop();
	    	}
	    //recognition.grammars = {"NAPO","IPLUS","RDR"};
	    
	}
function yes(ev){
	console.log(ev);
	console.log(counter);
	$(ev).parents("li").hide();
	counter++;
	draw("left", currentData[counter]);	
	voiceout(currentData[counter]);
	console.log(counter , currentData.length )
	if(currentData.length > 1 && counter < currentData.length-1){
	//draw("left", '<span>do u want to know more ? </span><button id="yes" onclick="yes(this)">yes</button> <button id="no" onclick="no(this)">No</button>');
		setTimeout(function(){
			    draw("left", ' <span style=" font-weight: 550; font-size: 15.5px;">Do you want to know more ? </span> <button id="yes" onclick="yes(this)" style=" font-weight: 600; border-radius: 10px; background-color: #05ab05;color: white;">yes</button> <button id="no" onclick="no(this)" style="font-weight: 700; border-radius: 10px;color: white; background-color: rgb(251, 22, 5);border-color: #c58a7c;">No</button>');
		},500);
		var knowMore="Do you want to know more about this ? Click Yes or No";
		voiceout(knowMore);
	}
}
function no(ev){
	var end="Thank you, Hope I helped you."
	draw("left", end);
	voiceout(end);
	console.log($(ev).parents("li"));
	$(ev).parents("li").hide();
}

function sendM(event){
	if (event.which == 13) {
		        event.preventDefault();
		        //sendMessage();
		connect();
		    }

}


function draw(side, text) {
	console.log("drawing...");
    var $message;
    $message = $($('.message_template').clone().html());
    $message.addClass(side).find('.text').html(text);
    $('.messages').append($message);
    return setTimeout(function () {
    	$(".messages").scrollTop(jQuery(".messages")[0].scrollHeight);
        return $message.addClass('appeared');
    }, 0);

}
function showWidget(){
	$("#widget").removeClass("hidewidget widget-fadeOut");	 
	 $("#widget-close").removeClass("hidewidget widget-fadeOut");
	 $("#widget").show();
	 $("#widget-close").show();
}
function openWidget(module) {	
	 closeWidget();
	 $('.messages').html("");
	$("#message_input_value").val("");
	 $('#message_input_value').typeahead('destroy');
	 console.log("inside open widget");
	 $.ajax({
	        url: '/chat/typeahead/'+module,
	        success: function(data){
	            typeAheadList = data;
	            $(".typeahead.dropdown-menu-cs").html("");	           
	            get();
	        }
	    });
		 function get() {
			 console.log(typeAheadList);
			 $('#message_input_value').typeahead({
					source: typeAheadList
			    });
		 }
	 $("#widget").removeClass("hidewidget widget-fadeOut");	 
	 $("#widget-close").removeClass("hidewidget widget-fadeOut");
	 $("#widget").show();
	 $("#widget-close").show();
	 console.log(currentModule);
	 currentModule = module;
	 console.log(currentModule);
	 var welcomeMsg="Hi , I'm your Toyota Bot. A new way to enhance your domain knowledge. How can I help you ?";
		draw("left",welcomeMsg);
		voiceout(welcomeMsg);

		
	
	 
}
function closeWidget() {
	 console.log("inside close widget");
	 $("#widget").addClass("hidewidget widget-fadeOut");	 
	 $("#widget-close").addClass("hidewidget widget-fadeOut");
	 $("#widget").hide();
	 $("#widget-close").hide();
	// disconnect();
}


/*function disconnect(){
	stompClient.disconnect();
}*/
function sendMessage(){
	console.log(currentModule);
		stompClient.send("/app/message", {}, JSON.stringify({'message': $("#message_input_value").val(),'appName':currentModule}));
		
	}
	


