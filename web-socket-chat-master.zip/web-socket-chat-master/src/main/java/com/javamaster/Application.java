package com.javamaster;

import java.io.FileNotFoundException;

import org.apache.sling.commons.json.JSONException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) throws FileNotFoundException, JSONException {
	
		SpringApplication.run(Application.class);
	}
}
