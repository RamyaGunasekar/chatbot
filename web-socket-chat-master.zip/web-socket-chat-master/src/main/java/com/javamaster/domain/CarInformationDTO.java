package com.javamaster.domain;

import java.util.List;

public class CarInformationDTO {
	
	private List<String> response;
	
	private String carModelYear;
	
	private String carType;

	public List<String> getResponse() {
		return response;
	}

	public void setResponse(List<String> response) {
		this.response = response;
	}

	public String getCarModelYear() {
		return carModelYear;
	}

	public void setCarModelYear(String carModelYear) {
		this.carModelYear = carModelYear;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}
	
    
	

}
