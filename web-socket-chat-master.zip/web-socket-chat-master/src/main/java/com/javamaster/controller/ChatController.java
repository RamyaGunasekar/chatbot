package com.javamaster.controller;

import java.util.List;

import org.apache.sling.commons.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.javamaster.ApachePOIExcelRead;
import com.javamaster.domain.CarInformationDTO;
import com.javamaster.domain.Message;

@Controller
public class ChatController {

		@RequestMapping(value = "/chat/typeahead/{keyword}", method = RequestMethod.GET)
		@ResponseBody
	public List<String> getTypeAhead(@PathVariable String keyword) throws JSONException {
		ApachePOIExcelRead obj=new ApachePOIExcelRead();
		
		List<String> strList=obj.excelRead("src/main/Book1.xlsx",keyword);
		
		System.out.println(strList);
		return strList;
	
	}
	
	
	//@MessageMapping("/message")
	//@SendTo("/chat/messages")
	@RequestMapping(value = "/chat/messages", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public CarInformationDTO getMessages(@RequestBody Message message) throws JSONException {
		ApachePOIExcelRead obj=new ApachePOIExcelRead();
		List<String> str=obj.excelRead("src/main/Book1.xlsx",message);
		CarInformationDTO carInformationDTO=new CarInformationDTO();
		if(str.isEmpty()){
			str.add("sorry I dont understand you, ask your queries again For example: what is iplus");
		}
		System.out.println(str);
		carInformationDTO.setResponse(str);
		System.out.println(carInformationDTO);
		return carInformationDTO;
	}
}
