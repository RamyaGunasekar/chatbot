package com.javamaster;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.commons.json.JSONException;

import com.javamaster.domain.Message;

public class ApachePOIExcelRead {


	public static List<String> excelRead(String FILE_NAME,String keyword) throws JSONException {
		Map<String, List<String>> jsonOutput = new HashMap<>() ;
		List<String> msgList1 = new ArrayList<String>();
		try {

			FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet=null;
			if(("iplus".equalsIgnoreCase(keyword))){
			 datatypeSheet = workbook.getSheetAt(0);
			}
			else if(("napo".equalsIgnoreCase(keyword))){
				 datatypeSheet = workbook.getSheetAt(1);
				}
			else if(("C360".equalsIgnoreCase(keyword))){
				 datatypeSheet = workbook.getSheetAt(2);
				}
			
			getFinalMap(jsonOutput, datatypeSheet);

			for (Map.Entry<String, List<String>> str : jsonOutput.entrySet()) {

				msgList1.add(str.getKey().toString());

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return msgList1;
	}

	public static List<String> excelRead(String FILE_NAME, Message msg) throws JSONException {
		Map<String, List<String>> jsonOutput =new HashMap<>();
		List<String> msgList1 = new ArrayList<String>();
		List<String> response = new ArrayList<String>();
		try {

			FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet= null;
			if(("iplus".equalsIgnoreCase(msg.getAppName()))){
			 datatypeSheet = workbook.getSheetAt(0);
			}
			else if(("napo".equalsIgnoreCase(msg.getAppName()))){
				 datatypeSheet = workbook.getSheetAt(1);
				}
			else if(("C360".equalsIgnoreCase(msg.getAppName()))){
				 datatypeSheet = workbook.getSheetAt(2);
				}
			getFinalMap(jsonOutput, datatypeSheet);
			
			for (Map.Entry<String, List<String>> str : jsonOutput.entrySet()) {

				if (str.getKey().equalsIgnoreCase(msg.getMessage())) {
					response = str.getValue();
					break;
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return response;
	}

	private static void getFinalMap(Map<String, List<String>> jsonOutput, Sheet datatypeSheet) {
		Iterator<Row> iterator = datatypeSheet.iterator();
		
		while (iterator.hasNext()) {
			List<String> msgList = new ArrayList<String>();
			Row currentRow = iterator.next();
		    String key=currentRow.getCell(0).toString();
			Iterator<Cell> cellIterator = currentRow.iterator();
			cellIterator.next();
			while (cellIterator.hasNext()) {
				Cell currentCell = cellIterator.next();
				if (currentCell.getCellTypeEnum() == CellType.STRING && null!=currentCell.getStringCellValue()) {
					msgList.add(currentCell.getStringCellValue());
				}
			}
			if(key!=null){
			jsonOutput.put(key, msgList);
			}
		}
	}

}
